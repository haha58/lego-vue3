export const LOGIN = 'login'
export const LOGOUT = 'logout'

export const GETTEMPLATEBYID = 'getTemplateById'

/** 组件列表 */
export const ADDCOMPONENT = 'addComponent'
export const DELCOMPONENT = 'delComponent'
export const SETCURRENTCOMPONENTID = 'setCurrentComponentId'
export const SETCURRENTCOMPONENT = 'setCurrentComponent'
export const UPDATECOMPONENT = 'updateComponent'
