import { TextComponentProps } from './defaultProps'

export interface TextTemplateProps extends TextComponentProps {
  id: string
  tag: string
}
